﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rpg_game
{
    class Karakter
    {
        public string Character_name { get; set; }

        public string Character_class { get; set; }

        public string Character_race { get; set; }

        public int Strength { get; set; }

        public int Defense { get; set; }

        public int Health { get; set; }

        public int Intelligence { get; set; }

        public Karakter(string name, string kclass, string race, int strength, int health, int defense, int intelligence) { 
            this.Character_name = name;
            this.Character_class = kclass;
            this.Character_race = race;
            this.Strength = strength;
            this.Health = health;
            this.Defense = defense;
            this.Intelligence = intelligence;
        }
    }
}
