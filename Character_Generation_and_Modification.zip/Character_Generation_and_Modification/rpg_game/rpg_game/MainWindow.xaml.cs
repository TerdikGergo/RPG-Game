﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace rpg_game
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Karakter> list = new();
        int karakterStrength = 0;
        int karakterHealth = 0;
        int karakterDefense = 0;
        int karakterIntelligence = 0;
        string karakterRace = "";
        string karakterName = "";
        string karakterClass = "";
        public MainWindow()
        {
            InitializeComponent();
            elsoBetoltesPontSzetosztas();
        }
        private void elsoBetoltesPontSzetosztas()
        {
            raceComboBox.Items.Add("Ork");
            raceComboBox.Items.Add("Skeleton");
            raceComboBox.Items.Add("Elf");
            raceComboBox.Items.Add("Barbarian");
            classComboBox.Items.Add("Meele");
            classComboBox.Items.Add("Ranged");
            classComboBox.Items.Add("Wizard");
            Random random = new Random();
            for (int i = 0; i < 20; i++) {
                int randomIndex = random.Next(0,4);
                switch (randomIndex)
                {
                    case 0:
                        karakterStrength += 1;
                        break;
                    case 1:
                        karakterHealth += 1;
                        break;
                    case 2:
                        karakterDefense += 1;
                        break;
                    case 3:
                        karakterIntelligence += 1;
                        break;
                }
            }
            refresh();
        }

        private void Randomnev_generalas_button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string[] names = File.ReadAllLines("names.txt");
                Random random = new Random();
                string randomName = names[random.Next(names.Length)];
                karakterName = randomName;
                nameTextBox.Text = randomName.Trim();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba a random nev generalasa kozben: " + ex.Message);
            }
        }

        private void karakterBetoltes_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new();
            ofd.Filter = "text files (*.txt)|*.txt";
            ofd.RestoreDirectory = true;
            if (ofd.ShowDialog() == true)
            {
                try
                {
                    foreach (var item in File.ReadAllLines(ofd.FileName))
                    {
                        string[] parts = item.Split(',');
                        karakterName = parts[0];
                        karakterClass = parts[1];
                        karakterRace = parts[2];
                        karakterStrength = Convert.ToInt32((string)parts[3]);
                        karakterHealth = Convert.ToInt32((string)parts[4]);
                        karakterDefense = Convert.ToInt32((string)parts[5]);
                        karakterIntelligence = Convert.ToInt32((string)parts[6]);
                        if (karakterClass == "Meele") { 
                            classComboBox.SelectedIndex = 0;
                        }
                        else if (karakterClass == "Ranged")
                        {
                            classComboBox.SelectedIndex = 1;
                        }
                        else if (karakterClass == "Wizard")
                        {
                            classComboBox.SelectedIndex = 2;
                        }
                        if (karakterRace == "Ork")
                        {
                            raceComboBox.SelectedIndex = 0;
                            karakterStrength -= 1;
                            karakterHealth += 1;
                        }
                        else if (karakterRace == "Skeleton")
                        {
                            raceComboBox.SelectedIndex = 1;
                            karakterStrength++;
                            karakterHealth--;
                        }
                        else if (karakterRace == "Elf")
                        {
                            raceComboBox.SelectedIndex = 2;
                            karakterIntelligence -= 1;
                            karakterHealth += 1;
                        }
                        else if (karakterRace == "Barbarian")
                        {
                            raceComboBox.SelectedIndex = 3;
                            karakterIntelligence += 1;
                            karakterHealth -= 1;
                        }
                        list.Add(new Karakter(karakterName, karakterClass, karakterRace, karakterStrength, karakterHealth, karakterDefense, karakterIntelligence));
                    }
                    refresh();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void karakterMentes_Click(object sender, RoutedEventArgs e)
        {
            string path = @$"C:\Users\Terdik Gergő\source\repos\TerdikGergo\RPG-Game\Character_Generation_and_Modification\rpg_game\rpg_game\bin\Debug\net7.0-windows\{karakterName}.txt";
            if (!File.Exists(path))
            {   
                using (StreamWriter sw = new StreamWriter(path, true))
                {
                   sw.WriteLine($"{karakterName},{karakterClass},{karakterRace},{karakterStrength},{karakterHealth},{karakterDefense},{karakterIntelligence}");
                }
            }
            else if (File.Exists(path))
            {
                using (var sw = new StreamWriter(path))
                {
                    sw.WriteLine($"{karakterName},{karakterClass},{karakterRace},{karakterStrength},{karakterHealth},{karakterDefense},{karakterIntelligence}");
                }
            }
            list.Add(new Karakter(karakterName, karakterClass, karakterRace, karakterStrength, karakterHealth, karakterDefense, karakterIntelligence));
            string filepath = @"C:\Users\Terdik Gergő\source\repos\TerdikGergo\RPG-Game\Character_Generation_and_Modification\rpg_game\rpg_game\bin\Debug\net7.0-windows\allBuildsSaved.txt";
            using (StreamWriter sw = new StreamWriter(filepath, true))
            {
                sw.WriteLine($"{karakterName},{karakterClass},{karakterRace},{karakterStrength},{karakterHealth},{karakterDefense},{karakterIntelligence}");
            }
        }
        private void raceComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (raceComboBox.SelectedIndex == 0)
            {
                karakterStrength += 1;
                karakterHealth -= 1;
                karakterRace = "Ork";
            }
            else if (raceComboBox.SelectedIndex == 1)
            {
                karakterStrength -= 1;
                karakterHealth += 1;
                karakterRace = "Skeleton";
            }
            else if (raceComboBox.SelectedIndex == 2)
            {
                karakterIntelligence += 1;
                karakterHealth -= 1;
                karakterRace = "Elf";
            }
            else if (raceComboBox.SelectedIndex == 3)
            {
                karakterIntelligence -= 1;
                karakterHealth += 1;
                karakterRace = "Barbarian";
            }
            refresh();
        }
        private void refresh() {
            nameTextBox.Text = $"{karakterName}";
            strengthTextBox.Text = $"Strenght: {karakterStrength}";
            healthTextBox.Text = $"Health: {karakterHealth}";
            defenseTextBox.Text = $"Defense: {karakterDefense}";
            intelligenceTextBox.Text = $"Intelligence: {karakterIntelligence}";
        }
        private void classComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (classComboBox.SelectedIndex == 0)
            {
                karakterClass = "Meele";
            }
            else if (classComboBox.SelectedIndex == 1)
            {
                karakterClass = "Ranged";
            }
            else if (classComboBox.SelectedIndex == 2)
            {
                karakterClass = "Wizard";
            }
            refresh();
        }
        private void strengthP_Click(object sender, RoutedEventArgs e)
        {
            if (karakterHealth - 1 == 0)
            {
                karakterHealth = 1;
            }
            else {
                karakterHealth--;
                karakterStrength++;
            }
            refresh();
        }
        private void strengthN_Click(object sender, RoutedEventArgs e)
        {
            if (karakterStrength - 1 == 0)
            {
                karakterStrength = 1;
            }
            else
            {
                karakterStrength--;
                karakterHealth++;
            }
            refresh();
        }
        private void healthP_Click(object sender, RoutedEventArgs e)
        {
            if (karakterDefense - 1 == 0)
            {
                karakterDefense = 1;
            }
            else
            {
                karakterDefense--;
                karakterHealth++;
            }
            refresh();
        }
        private void healthN_Click(object sender, RoutedEventArgs e)
        {
            if (karakterHealth - 1 == 0)
            {
                karakterHealth = 1;
            }
            else
            {
                karakterHealth--;
                karakterDefense++;
            }
            refresh();
        }
        private void defenseP_Click(object sender, RoutedEventArgs e)
        {
            if (karakterIntelligence - 1 == 0)
            {
                karakterIntelligence = 1;
            }
            else
            {
                karakterIntelligence--;
                karakterDefense++;
            }
            refresh();
        }
        private void defenseN_Click(object sender, RoutedEventArgs e)
        {
            if (karakterDefense - 1 == 0)
            {
                karakterDefense = 1;
            }
            else
            {
                karakterDefense--;
                karakterIntelligence++;
            }
            refresh();
        }
        private void intelligenceP_Click(object sender, RoutedEventArgs e)
        {
            if (karakterStrength - 1 == 0)
            {
                karakterStrength = 1;
            }
            else
            {
                karakterStrength--;
                karakterIntelligence++;
            }   
            refresh();
        }
        private void intelligenceN_Click(object sender, RoutedEventArgs e)
        {   
            if (karakterIntelligence-1 == 0)
            {
                karakterIntelligence = 1;
            }
            else
            {
                karakterIntelligence--;
                karakterStrength++;
            }
            refresh();
        }
    }
}