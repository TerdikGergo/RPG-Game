﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace rpggame
{
    public partial class MainWindow : Window
    {
        private Character player;
        private Enemy enemy;
        private Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            // Initialize player and enemy
            player = new Character("Player", 100, 10, 10, 10);
            enemy = GenerateRandomEnemy();

            UpdateUI();
        }

        private Enemy GenerateRandomEnemy()
        {
            // Generate random enemy attributes
            int health = 100;
            int strength = random.Next(5, 15);
            int agility = random.Next(5, 15);
            int intelligence = random.Next(5, 15);

            return new Enemy("Enemy", health, strength, agility, intelligence);
        }

        private void UpdateUI()
        {
            // Update UI elements to display player and enemy attributes
            playerNameLabel.Content = player.Name;
            playerHealthLabel.Content = player.Health.ToString();

            enemyNameLabel.Content = enemy.Name;
            enemyHealthLabel.Content = enemy.Health.ToString();
        }

        private async void AttackButton_Click(object sender, RoutedEventArgs e)
        {
            // Disable attack button during combat
            attackButton.IsEnabled = false;

            while (player.Health > 0 && enemy.Health > 0)
            {
                await Task.Delay(1000);

                // Player's turn
                int playerDamage = CalculateDamage(player);
                enemy.TakeDamage(playerDamage);
                UpdateUI();

                if (enemy.Health <= 0)
                {
                    MessageBox.Show("You win! Enemy defeated.");
                    player.GainXP(50);
                    enemy = GenerateRandomEnemy(); // Generate new enemy
                    UpdateUI();
                    break;
                }

                await Task.Delay(1000); // Delay for better visualization

                // Enemy's turn
                int enemyDamage = CalculateDamage(enemy);
                player.TakeDamage(enemyDamage);
                UpdateUI();

                if (player.Health <= 0)
                {
                    MessageBox.Show("You lose! Your health dropped to 0.");
                    player.RestoreHealth();
                    UpdateUI();
                    break;
                }
            }

            // Enable attack button after combat ends
            attackButton.IsEnabled = true;
        }

        private int CalculateDamage(Character character)
        {
            // Calculate damage based on character's strength
            return random.Next(1, character.Strength + 1);
        }
    }

    public class Character : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string name;
        private int health;
        private int strength;
        private int agility;
        private int intelligence;
        private int experience;
        private int level;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                NotifyPropertyChanged(nameof(Name));
            }
        }

        public int Health
        {
            get { return health; }
            set
            {
                health = value;
                NotifyPropertyChanged(nameof(Health));
            }
        }

        public int Strength
        {
            get { return strength; }
            set
            {
                strength = value;
                NotifyPropertyChanged(nameof(Strength));
            }
        }

        public int Agility
        {
            get { return agility; }
            set
            {
                agility = value;
                NotifyPropertyChanged(nameof(Agility));
            }
        }

        public int Intelligence
        {
            get { return intelligence; }
            set
            {
                intelligence = value;
                NotifyPropertyChanged(nameof(Intelligence));
            }
        }

        public int Experience
        {
            get { return experience; }
            set
            {
                experience = value;
                NotifyPropertyChanged(nameof(Experience));
            }
        }

        public int Level
        {
            get { return level; }
            set
            {
                level = value;
                NotifyPropertyChanged(nameof(Level));
            }
        }

        public Character(string name, int health, int strength, int agility, int intelligence)
        {
            Name = name;
            Health = health;
            Strength = strength;
            Agility = agility;
            Intelligence = intelligence;
            Experience = 0;
            Level = 1;
        }

        public void TakeDamage(int damage)
        {
            Health -= damage;
        }

        public void RestoreHealth()
        {
            Health = 100;
        }

        public void GainXP(int amount)
        {
            Experience += amount;
            CheckLevelUp();
        }

        private void CheckLevelUp()
        {
            // Check if current experience exceeds required experience for next level
            int requiredExperience = CalculateRequiredExperience(Level);
            if (Experience >= requiredExperience)
            {
                Level++;
                // Increase attributes upon leveling up
                Strength += 2;
                Agility += 1;
                Intelligence += 1;
                Experience -= requiredExperience;
                CheckLevelUp(); // Check for additional level ups if enough experience is gained
            }
        }

        private int CalculateRequiredExperience(int level)
        {
            return level * 100;
        }

        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class Enemy : Character
    {
        public Enemy(string name, int health, int strength, int agility, int intelligence)
            : base(name, health, strength, agility, intelligence)
        {
        }
    }
}
